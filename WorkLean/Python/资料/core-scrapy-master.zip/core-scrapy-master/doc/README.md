# README

## Scrapy 教程

Scrapy是python开发的著名爬虫框架，目前使用非常广泛。本教程基于最新的1.0版本，
通过实际的例子带领你一步步掌握Scrapy核心，以后会持续更新改进。

* readthedocs:  <http://scrapy-cookbook.readthedocs.io/zh_CN/latest/>
* PDF下载:       <http://pan.baidu.com/s/1c2BZfGG>

## License

MIT

## Powered by

This is a book powered by [GitBook](https://github.com/GitbookIO/gitbook).

