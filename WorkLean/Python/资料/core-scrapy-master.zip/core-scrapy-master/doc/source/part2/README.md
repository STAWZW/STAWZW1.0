## 核心组件

这一部分开始介绍scrapy里面的核心组件，包括了Spider、Selector、Item、Pipeline、内置服务，以及文件和图片的处理。
